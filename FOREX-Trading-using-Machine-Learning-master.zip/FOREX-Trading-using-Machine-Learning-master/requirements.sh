#!/bin/sh
# Copyright (c) Tutorialspoint.com
# Script follows here:

pip install numpy
pip install pandas
pip install missingno
pip install matplotlib
pip install seaborn
pip install datetime 
pip install missingno
pip install pandas_profiling
pip install scipy
pip install scipy
pip install math 
pip install pandas_profiling
pip install sklearn
pip install tensorflow as tf
pip install plotly
pip install cufflinks as cf
